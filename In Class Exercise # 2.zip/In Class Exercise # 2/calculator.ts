// Name: Aryan Jajadiya
// Student ID: 100894608
// ICE : 02
// File: calculator.ts

const add = (a: number, b: number): number => {
    return a + b;
  }
  
  const subtract = (a: number, b: number): number => {
    return a - b;
  }
  
  const multiply = (a: number, b: number): number => {
    return a * b;
  }
  
  const divide = (a: number, b: number): number => {
    return a / b;
  }
  
  export {
    add,
    subtract,
    multiply,
    divide
  };
  